package com.example.aplikacja;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
//    public static final String EXTRA_Number_1 = "com.example.aplikacja.Extra_Number_1";
//    public static final String EXTRA_Number_2 = "com.example.aplikacja.Extra_Number_2";

    private TextView wynikObliczen;

    @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wynikObliczen = findViewById(R.id.textViewA);


        Button button = (Button) findViewById(R.id.button);
         button.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 openActivity2();

             }
         });

           }

           public void openActivity2(){
               EditText editText1 = (EditText) findViewById(R.id.editText1);
                int number1 =Integer.parseInt(editText1.getText().toString());
               EditText editText2 = (EditText) findViewById(R.id.editText2);
                int number2 =Integer.parseInt(editText2.getText().toString());
//
               Intent intent = new Intent(this, drugaAktywnosc.class);
               intent.putExtra("test",number1);
               intent.putExtra("Test2",number2);

                startActivityForResult(intent, 1);


           }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1){
            if(resultCode == Activity.RESULT_OK) {
                    int newInt = data.getIntExtra("nowy",0);
                    wynikObliczen.setText(""+ newInt);
                }

            }
        }
    }








